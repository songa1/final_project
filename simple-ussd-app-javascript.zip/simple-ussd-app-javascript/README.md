# simple-ussd-app-javascript

This is a simple USSD Application made with JavaScript Node JS and Express Framework

Made by [Cishahayo Songa Achille](https://github.com/songa1)

## Resources

Resources used: [Andela Article](https://andela.com/insights/africas-talking-node-js-express-ussd-application/) and [Francis Kagal's Video](https://youtu.be/xNLMCpWcj-4)

(c) Achille Songa 2023

const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");

let apiUrl = "http://localhost:3456";

const app = express();

let meter;

app.listen(5000, () => {
  console.log("listening on port 5000");
});

app.use(bodyParser());
app.use(bodyParser.urlencoded({ extended: false }));

app.post("/", (req, res) => {
  const { sessionId, sessionCode, phoneNumber, text } = req.body;

  let response = "";

  if (text == "") {
    response = `CON Welcome to SMART ENERGY METER?
        
        1. Check your meter balance
        2. Recharge your meter power`;
        res.set("Content-Type", "text/plain");
        res.send(response);
  } else if (text == "1") {
    response = `CON Enter your meter number:`;
    res.set("Content-Type", "text/plain");
  res.send(response);
  } else if (text.startsWith("1*")) {
    console.log(text)
    const meterNumber = text.split("*")[1];
    axios.get(apiUrl+`/get-power`, {
      params: {
        meter: meterNumber,
      }
    }).then(data => {
      response = `END You have ${data.data.data.power} Kwh in your meter.`;
      res.set("Content-Type", "text/plain");
      res.send(response);
    }).catch(err => {
      console.log(err.message);
    })
    
  } else if (text == "2") {
    console.log(text)
    response = `CON Enter your meter number!`;
    res.set("Content-Type", "text/plain");
    res.send(response);
  } else if(text.startsWith(`2*`) && text.split("*")[1].startsWith("250") && text.split("*")[2] == null){
    console.log(text)
    let meterN = text.split("*")[1];
    meter = meterN;
    response = `CON Enter the amount to recharge!`;
    res.set("Content-Type", "text/plain");
  res.send(response);
  }else if(text.split("*").length == 3){
    console.log(text)
    const amountToRecharge = parseInt(text.split("*")[2])
    if(amountToRecharge < 100) {
      response = `END The minimum amount to charge is 100.`;
      res.set("Content-Type", "text/plain");
      res.send(response);
    }else{
      axios.get(apiUrl + `/new-transaction`, {
        params: {
          meter: meter,
          amount: amountToRecharge,
        }
      })
      .then(data => {
        console.log(data);
          response = `END Your transaction of ${amountToRecharge} RWF was successful! You got ${data.data.data.power} Kwh.`;
          res.set("Content-Type", "text/plain");
          res.send(response);
      }).catch(err => {
        console.log(err.message);
      });
    }
    
  } else {
    response = `END Wrong choice!`;
    res.set("Content-Type", "text/plain");
  res.send(response);
  }
});

module.exports = app;
